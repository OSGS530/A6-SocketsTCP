package E6.Protocol;

public class ProtocolMethodNotFoundException extends Exception{
}
