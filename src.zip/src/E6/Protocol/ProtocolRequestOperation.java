package E6.Protocol;

public class ProtocolRequestOperation {
    public static int AREA_CILINDRO = 1;
    public static int AREA_ESFERA = 2;
    public static int AREA_CONO = 3;
    public static int AREA_CUBO = 4;
    public static int AREA_PRISMA = 5;
    public static int AREA_PIRAMIDE = 6;
    public static int VOLUMEN_CILINDRO = 7;
    public static int VOLUMEN_ESFERA = 8;
    public static int VOLUMEN_CONO = 9;
    public static int VOLUMEN_CUBO = 10;
    public static int VOLUMEN_PRISMA = 11;
    public static int VOLUMEN_PIRAMIDE = 12;
}