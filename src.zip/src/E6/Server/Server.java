package E6.Server;

import java.io.IOException;

public interface Server {
    public void start(int port) throws IOException;
}
